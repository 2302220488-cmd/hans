document.addEventListener('DOMContentLoaded',()=>{
 const menu=document.getElementById('menuBtn'),side=document.getElementById('sidebar');
 if(menu&&side) menu.addEventListener('click',()=>side.classList.toggle('show'));
 const search=document.getElementById('tableSearch');
 if(search) search.addEventListener('input',()=>{const q=search.value.toLowerCase();document.querySelectorAll('tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')});
});
