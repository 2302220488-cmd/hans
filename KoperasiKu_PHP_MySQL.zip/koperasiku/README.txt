KOPERASIKU - WEBSITE SIMPAN PINJAM PHP MYSQL

CARA MENJALANKAN DI XAMPP
1. Ekstrak folder koperasiku ke C:\xampp\htdocs\
2. Buka XAMPP Control Panel, aktifkan Apache dan MySQL.
3. Buka http://localhost/phpmyadmin
4. Pilih tab Import, pilih file database.sql dari folder koperasiku, lalu klik Import.
5. Pastikan pengaturan database di config.php sesuai:
   host localhost, database koperasiku, user root, password kosong (default XAMPP).
6. Buka http://localhost/koperasiku

LOGIN AWAL
Username: admin
Password: password

FITUR
- Login administrator
- Dashboard ringkasan anggota, simpanan, pinjaman, transaksi terbaru
- Tambah, edit, hapus, cari data anggota
- Catat dan lihat transaksi simpanan
- Catat pinjaman dengan bunga dan tenor
- Catat pembayaran angsuran, hitung sisa dan status lunas
- Laporan anggota, simpanan, pinjaman, cetak melalui browser

CATATAN
- Ini merupakan aplikasi pembelajaran/praktik. Uji dengan data contoh terlebih dahulu.
- Untuk penggunaan nyata, tambahkan pengelolaan admin, audit log, backup, validasi bisnis, dan pengaturan hak akses.
- Pastikan hanya admin yang berwenang dapat mengakses website.
