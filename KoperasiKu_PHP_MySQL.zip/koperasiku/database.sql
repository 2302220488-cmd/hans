CREATE DATABASE IF NOT EXISTS koperasiku CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE koperasiku;

CREATE TABLE IF NOT EXISTS admin (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 nama VARCHAR(100) NOT NULL
);
CREATE TABLE IF NOT EXISTS anggota (
 id INT AUTO_INCREMENT PRIMARY KEY,
 no_anggota VARCHAR(30) NOT NULL UNIQUE,
 nama VARCHAR(120) NOT NULL,
 jk ENUM('Laki-laki','Perempuan') NOT NULL,
 alamat TEXT,
 telepon VARCHAR(25),
 tanggal_daftar DATE NOT NULL
);
CREATE TABLE IF NOT EXISTS simpanan (
 id INT AUTO_INCREMENT PRIMARY KEY,
 anggota_id INT NOT NULL,
 jenis ENUM('Pokok','Wajib','Sukarela') NOT NULL,
 jumlah DECIMAL(14,2) NOT NULL,
 tanggal DATE NOT NULL,
 keterangan VARCHAR(255),
 FOREIGN KEY (anggota_id) REFERENCES anggota(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS pinjaman (
 id INT AUTO_INCREMENT PRIMARY KEY,
 anggota_id INT NOT NULL,
 jumlah DECIMAL(14,2) NOT NULL,
 bunga DECIMAL(5,2) NOT NULL DEFAULT 0,
 tenor INT NOT NULL,
 tanggal DATE NOT NULL,
 status ENUM('Berjalan','Lunas') NOT NULL DEFAULT 'Berjalan',
 keterangan VARCHAR(255),
 FOREIGN KEY (anggota_id) REFERENCES anggota(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS angsuran (
 id INT AUTO_INCREMENT PRIMARY KEY,
 pinjaman_id INT NOT NULL,
 jumlah DECIMAL(14,2) NOT NULL,
 tanggal DATE NOT NULL,
 keterangan VARCHAR(255),
 FOREIGN KEY (pinjaman_id) REFERENCES pinjaman(id) ON DELETE RESTRICT
);

-- Login awal: admin / password
INSERT IGNORE INTO admin(username,password,nama)
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator');
