<?php
require 'config.php';
verify_csrf();
$page = $_GET['page'] ?? 'dashboard';
$allowed = ['dashboard','anggota','simpanan','pinjaman','angsuran','laporan'];
if (!in_array($page, $allowed, true)) $page='dashboard';

if (isset($_GET['logout'])) { session_destroy(); redirect('index.php'); }
if (isset($_POST['login'])) {
    $q=$pdo->prepare("SELECT * FROM admin WHERE username=?"); $q->execute([trim($_POST['username'])]); $a=$q->fetch();
    if ($a && password_verify($_POST['password'], $a['password'])) {
        session_regenerate_id(true); $_SESSION['admin_id']=$a['id']; $_SESSION['admin_nama']=$a['nama']; redirect();
    } else $login_error='Username atau password salah.';
}
if (!isset($_SESSION['admin_id'])):
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Login | KoperasiKu</title><link rel="stylesheet" href="assets/style.css"></head>
<body class="login-page"><div class="login-card"><div class="brand-mark">K</div><h1>KoperasiKu</h1><p class="muted">Sistem Informasi Simpan Pinjam</p>
<?php if (!empty($login_error)): ?><div class="alert"><?=e($login_error)?></div><?php endif; ?>
<form method="post"><?=csrf_field()?><label>Username</label><input name="username" required autofocus placeholder="Masukkan username"><label>Password</label><input type="password" name="password" required placeholder="Masukkan password"><button class="btn primary full" name="login">Masuk ke Dashboard</button></form><small>Login awal: <b>admin</b> / <b>password</b></small></div></body></html>
<?php exit; endif;

function postv($k,$default=''){ return trim($_POST[$k] ?? $default); }
if ($_SERVER['REQUEST_METHOD']==='POST' && !isset($_POST['login'])) {
 try {
  if (isset($_POST['save_anggota'])) {
   $id=(int)($_POST['id']??0); $data=[postv('no_anggota'),postv('nama'),postv('jk'),postv('alamat'),postv('telepon'),postv('tanggal_daftar')];
   if($id){$s=$pdo->prepare("UPDATE anggota SET no_anggota=?,nama=?,jk=?,alamat=?,telepon=?,tanggal_daftar=? WHERE id=?");$s->execute([...$data,$id]);}
   else {$s=$pdo->prepare("INSERT INTO anggota(no_anggota,nama,jk,alamat,telepon,tanggal_daftar) VALUES(?,?,?,?,?,?)");$s->execute($data);}
   $_SESSION['flash']='Data anggota berhasil disimpan.';
  }
  if (isset($_POST['delete_anggota'])) {
   $s=$pdo->prepare("DELETE FROM anggota WHERE id=?");$s->execute([(int)$_POST['id']]);$_SESSION['flash']='Data anggota dihapus.';
  }
  if (isset($_POST['save_simpanan'])) {
   $s=$pdo->prepare("INSERT INTO simpanan(anggota_id,jenis,jumlah,tanggal,keterangan) VALUES(?,?,?,?,?)");
   $s->execute([(int)$_POST['anggota_id'],postv('jenis'),(float)$_POST['jumlah'],postv('tanggal'),postv('keterangan')]);$_SESSION['flash']='Transaksi simpanan berhasil dicatat.';
  }
  if (isset($_POST['save_pinjaman'])) {
   $s=$pdo->prepare("INSERT INTO pinjaman(anggota_id,jumlah,bunga,tenor,tanggal,keterangan) VALUES(?,?,?,?,?,?)");
   $s->execute([(int)$_POST['anggota_id'],(float)$_POST['jumlah'],(float)$_POST['bunga'],(int)$_POST['tenor'],postv('tanggal'),postv('keterangan')]);$_SESSION['flash']='Pinjaman berhasil dicatat.';
  }
  if (isset($_POST['save_angsuran'])) {
   $pid=(int)$_POST['pinjaman_id']; $amount=(float)$_POST['jumlah'];
   $s=$pdo->prepare("SELECT p.jumlah*(1+p.bunga/100) AS total, COALESCE((SELECT SUM(jumlah) FROM angsuran WHERE pinjaman_id=p.id),0) AS dibayar FROM pinjaman p WHERE p.id=? AND p.status='Berjalan'");
   $s->execute([$pid]);$p=$s->fetch();
   if(!$p || $amount<=0 || $amount > ($p['total']-$p['dibayar'])) throw new Exception('Nominal angsuran tidak valid atau melebihi sisa pinjaman.');
   $s=$pdo->prepare("INSERT INTO angsuran(pinjaman_id,jumlah,tanggal,keterangan) VALUES(?,?,?,?)");$s->execute([$pid,$amount,postv('tanggal'),postv('keterangan')]);
   if($amount >= $p['total']-$p['dibayar']) {$pdo->prepare("UPDATE pinjaman SET status='Lunas' WHERE id=?")->execute([$pid]);}
   $_SESSION['flash']='Pembayaran angsuran berhasil dicatat.';
  }
 } catch(Exception $ex) { $_SESSION['flash_error']=$ex->getMessage(); }
 redirect('index.php?page='.$page);
}
$flash=$_SESSION['flash']??''; unset($_SESSION['flash']); $flash_error=$_SESSION['flash_error']??''; unset($_SESSION['flash_error']);
$anggota=$pdo->query("SELECT * FROM anggota ORDER BY id DESC")->fetchAll();
$anggota_count=(int)$pdo->query("SELECT COUNT(*) FROM anggota")->fetchColumn();
$total_simpanan=(float)$pdo->query("SELECT COALESCE(SUM(jumlah),0) FROM simpanan")->fetchColumn();
$total_pinjaman=(float)$pdo->query("SELECT COALESCE(SUM(jumlah),0) FROM pinjaman")->fetchColumn();
$recent=$pdo->query("SELECT 'Simpanan' tipe,a.nama,s.jumlah,s.tanggal FROM simpanan s JOIN anggota a ON a.id=s.anggota_id UNION ALL SELECT 'Pinjaman',a.nama,p.jumlah,p.tanggal FROM pinjaman p JOIN anggota a ON a.id=p.anggota_id UNION ALL SELECT 'Angsuran',a.nama,g.jumlah,g.tanggal FROM angsuran g JOIN pinjaman p ON p.id=g.pinjaman_id JOIN anggota a ON a.id=p.anggota_id ORDER BY tanggal DESC LIMIT 8")->fetchAll();
$edit=null;if($page==='anggota' && isset($_GET['edit'])){$s=$pdo->prepare("SELECT * FROM anggota WHERE id=?");$s->execute([(int)$_GET['edit']]);$edit=$s->fetch();}
?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title><?=ucfirst($page)?> | KoperasiKu</title><link rel="stylesheet" href="assets/style.css"></head><body>
<div class="app"><aside class="sidebar" id="sidebar"><div class="brand"><span class="brand-mark small">K</span><div><b>KoperasiKu</b><small>ADMIN PANEL</small></div></div><nav>
<a class="<?=$page==='dashboard'?'active':''?>" href="?page=dashboard">▦ <span>Dashboard</span></a>
<a class="<?=$page==='anggota'?'active':''?>" href="?page=anggota">♙ <span>Data Anggota</span></a>
<a class="<?=$page==='simpanan'?'active':''?>" href="?page=simpanan">＋ <span>Simpanan</span></a>
<a class="<?=$page==='pinjaman'?'active':''?>" href="?page=pinjaman">↗ <span>Pinjaman</span></a>
<a class="<?=$page==='angsuran'?'active':''?>" href="?page=angsuran">↻ <span>Angsuran</span></a>
<a class="<?=$page==='laporan'?'active':''?>" href="?page=laporan">▤ <span>Laporan</span></a>
</nav><div class="side-bottom"><small>Masuk sebagai</small><b><?=e($_SESSION['admin_nama'])?></b><a href="?logout=1" class="logout">⇥ Keluar</a></div></aside>
<main class="main"><header class="topbar"><button class="menu-btn" id="menuBtn">☰</button><div><b><?=ucfirst($page)?></b><small> / Sistem Informasi Simpan Pinjam</small></div><span class="admin-pill">● Administrator</span></header><section class="content">
<?php if($flash):?><div class="success"><?=e($flash)?></div><?php endif;?><?php if($flash_error):?><div class="alert"><?=e($flash_error)?></div><?php endif;?>
<?php if($page==='dashboard'):?>
<div class="welcome"><div><h1>Selamat datang, <?=e($_SESSION['admin_nama'])?> 👋</h1><p>Berikut ringkasan aktivitas koperasi hari ini.</p></div><span><?=date('d/m/Y')?></span></div>
<div class="stats"><div class="stat"><span>Total Anggota</span><strong><?=number_format($anggota_count)?></strong><small>Anggota terdaftar</small></div><div class="stat"><span>Total Simpanan</span><strong><?=rupiah($total_simpanan)?></strong><small>Akumulasi simpanan masuk</small></div><div class="stat"><span>Total Pinjaman</span><strong><?=rupiah($total_pinjaman)?></strong><small>Total pinjaman diberikan</small></div><div class="stat"><span>Pinjaman Berjalan</span><strong><?=$pdo->query("SELECT COUNT(*) FROM pinjaman WHERE status='Berjalan'")->fetchColumn()?></strong><small>Belum lunas</small></div></div>
<div class="panel"><div class="panel-head"><h2>Transaksi Terbaru</h2><a href="?page=laporan">Lihat laporan →</a></div><?php render_table_recent($recent);?></div>
<?php elseif($page==='anggota'):?>
<div class="page-head"><div><h1>Data Anggota</h1><p>Kelola informasi seluruh anggota koperasi.</p></div></div>
<div class="panel"><h2><?=$edit?'Edit Anggota':'Tambah Anggota'?></h2><form method="post" class="form-grid"><?=csrf_field()?><input type="hidden" name="id" value="<?=e($edit['id']??'')?>"><div><label>Nomor Anggota</label><input name="no_anggota" required value="<?=e($edit['no_anggota']??'')?>" placeholder="AGT-001"></div><div><label>Nama Lengkap</label><input name="nama" required value="<?=e($edit['nama']??'')?>"></div><div><label>Jenis Kelamin</label><select name="jk" required><option value="Laki-laki" <?=($edit['jk']??'')==='Laki-laki'?'selected':''?>>Laki-laki</option><option value="Perempuan" <?=($edit['jk']??'')==='Perempuan'?'selected':''?>>Perempuan</option></select></div><div><label>Nomor Telepon</label><input name="telepon" value="<?=e($edit['telepon']??'')?>"></div><div><label>Tanggal Daftar</label><input type="date" name="tanggal_daftar" required value="<?=e($edit['tanggal_daftar']??date('Y-m-d'))?>"></div><div><label>Alamat</label><input name="alamat" value="<?=e($edit['alamat']??'')?>"></div><div class="form-actions"><button class="btn primary" name="save_anggota">Simpan Anggota</button><?php if($edit):?><a class="btn light" href="?page=anggota">Batal</a><?php endif;?></div></form></div>
<div class="panel"><div class="panel-head"><h2>Daftar Anggota</h2><input class="search" id="tableSearch" placeholder="Cari anggota..."></div><div class="table-wrap"><table><thead><tr><th>No.</th><th>No Anggota</th><th>Nama</th><th>Jenis Kelamin</th><th>Telepon</th><th>Tanggal Daftar</th><th>Aksi</th></tr></thead><tbody><?php foreach($anggota as $i=>$a):?><tr><td><?=$i+1?></td><td><?=e($a['no_anggota'])?></td><td><b><?=e($a['nama'])?></b></td><td><?=e($a['jk'])?></td><td><?=e($a['telepon'])?></td><td><?=e($a['tanggal_daftar'])?></td><td><a class="action" href="?page=anggota&edit=<?=$a['id']?>">Edit</a><form method="post" class="inline" onsubmit="return confirm('Hapus anggota ini?')"><?=csrf_field()?><input type="hidden" name="id" value="<?=$a['id']?>"><button class="action danger" name="delete_anggota">Hapus</button></form></td></tr><?php endforeach;?></tbody></table></div></div>
<?php elseif($page==='simpanan'):?>
<div class="page-head"><div><h1>Transaksi Simpanan</h1><p>Catat simpanan pokok, wajib, dan sukarela anggota.</p></div></div>
<div class="panel"><h2>Tambah Simpanan</h2><form method="post" class="form-grid"><?=csrf_field()?><div><label>Anggota</label><select name="anggota_id" required><?php foreach($anggota as $a):?><option value="<?=$a['id']?>"><?=e($a['no_anggota'].' - '.$a['nama'])?></option><?php endforeach;?></select></div><div><label>Jenis Simpanan</label><select name="jenis"><option>Pokok</option><option>Wajib</option><option>Sukarela</option></select></div><div><label>Jumlah (Rp)</label><input type="number" name="jumlah" min="1" required></div><div><label>Tanggal</label><input type="date" name="tanggal" value="<?=date('Y-m-d')?>" required></div><div class="wide"><label>Keterangan</label><input name="keterangan" placeholder="Keterangan transaksi"></div><div class="form-actions"><button class="btn primary" name="save_simpanan">Simpan Transaksi</button></div></form></div>
<div class="panel"><div class="panel-head"><h2>Riwayat Simpanan</h2><b>Total: <?=rupiah($total_simpanan)?></b></div><?php $rows=$pdo->query("SELECT s.*,a.nama,a.no_anggota FROM simpanan s JOIN anggota a ON a.id=s.anggota_id ORDER BY s.tanggal DESC,s.id DESC")->fetchAll();?><div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Anggota</th><th>Jenis</th><th>Jumlah</th><th>Keterangan</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['tanggal'])?></td><td><?=e($r['no_anggota'].' - '.$r['nama'])?></td><td><span class="tag"><?=e($r['jenis'])?></span></td><td><?=rupiah($r['jumlah'])?></td><td><?=e($r['keterangan'])?></td></tr><?php endforeach;?></tbody></table></div></div>
<?php elseif($page==='pinjaman'):?>
<div class="page-head"><div><h1>Data Pinjaman</h1><p>Catat pengajuan pinjaman anggota koperasi.</p></div></div>
<div class="panel"><h2>Tambah Pinjaman</h2><form method="post" class="form-grid"><?=csrf_field()?><div><label>Anggota</label><select name="anggota_id" required><?php foreach($anggota as $a):?><option value="<?=$a['id']?>"><?=e($a['no_anggota'].' - '.$a['nama'])?></option><?php endforeach;?></select></div><div><label>Jumlah Pinjaman (Rp)</label><input type="number" name="jumlah" min="1" required></div><div><label>Bunga (%)</label><input type="number" name="bunga" min="0" step="0.01" value="0" required></div><div><label>Tenor (bulan)</label><input type="number" name="tenor" min="1" required></div><div><label>Tanggal</label><input type="date" name="tanggal" value="<?=date('Y-m-d')?>" required></div><div><label>Keterangan</label><input name="keterangan"></div><div class="form-actions"><button class="btn primary" name="save_pinjaman">Simpan Pinjaman</button></div></form></div>
<div class="panel"><h2>Daftar Pinjaman</h2><?php $rows=$pdo->query("SELECT p.*,a.nama,a.no_anggota,COALESCE(x.dibayar,0) dibayar FROM pinjaman p JOIN anggota a ON a.id=p.anggota_id LEFT JOIN (SELECT pinjaman_id,SUM(jumlah) dibayar FROM angsuran GROUP BY pinjaman_id) x ON x.pinjaman_id=p.id ORDER BY p.id DESC")->fetchAll();?><div class="table-wrap"><table><thead><tr><th>Anggota</th><th>Tanggal</th><th>Pinjaman</th><th>Total + Bunga</th><th>Terbayar</th><th>Sisa</th><th>Status</th></tr></thead><tbody><?php foreach($rows as $r):$total=$r['jumlah']*(1+$r['bunga']/100);$sisa=max(0,$total-$r['dibayar']);?><tr><td><?=e($r['no_anggota'].' - '.$r['nama'])?></td><td><?=e($r['tanggal'])?></td><td><?=rupiah($r['jumlah'])?></td><td><?=rupiah($total)?></td><td><?=rupiah($r['dibayar'])?></td><td><b><?=rupiah($sisa)?></b></td><td><span class="tag <?=$r['status']==='Lunas'?'green':''?>"><?=e($r['status'])?></span></td></tr><?php endforeach;?></tbody></table></div></div>
<?php elseif($page==='angsuran'):?>
<div class="page-head"><div><h1>Pembayaran Angsuran</h1><p>Catat pembayaran dan pantau sisa pinjaman.</p></div></div>
<div class="panel"><h2>Catat Pembayaran</h2><form method="post" class="form-grid"><?=csrf_field()?><div class="wide"><label>Pilih Pinjaman Berjalan</label><select name="pinjaman_id" required><?php foreach($pdo->query("SELECT p.*,a.nama,COALESCE(x.dibayar,0) dibayar FROM pinjaman p JOIN anggota a ON a.id=p.anggota_id LEFT JOIN (SELECT pinjaman_id,SUM(jumlah) dibayar FROM angsuran GROUP BY pinjaman_id) x ON x.pinjaman_id=p.id WHERE p.status='Berjalan'") as $p):?><option value="<?=$p['id']?>"><?=e($p['nama'])?> — Sisa <?=rupiah($p['jumlah']*(1+$p['bunga']/100)-$p['dibayar'])?></option><?php endforeach;?></select></div><div><label>Jumlah Angsuran (Rp)</label><input type="number" name="jumlah" min="1" required></div><div><label>Tanggal</label><input type="date" name="tanggal" value="<?=date('Y-m-d')?>" required></div><div class="wide"><label>Keterangan</label><input name="keterangan"></div><div class="form-actions"><button class="btn primary" name="save_angsuran">Simpan Pembayaran</button></div></form></div>
<div class="panel"><h2>Riwayat Angsuran</h2><?php $rows=$pdo->query("SELECT g.*,a.nama,p.id nomor FROM angsuran g JOIN pinjaman p ON p.id=g.pinjaman_id JOIN anggota a ON a.id=p.anggota_id ORDER BY g.tanggal DESC")->fetchAll();?><div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Anggota</th><th>ID Pinjaman</th><th>Jumlah</th><th>Keterangan</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['tanggal'])?></td><td><?=e($r['nama'])?></td><td>#<?=$r['nomor']?></td><td><?=rupiah($r['jumlah'])?></td><td><?=e($r['keterangan'])?></td></tr><?php endforeach;?></tbody></table></div></div>
<?php elseif($page==='laporan'):?>
<div class="page-head"><div><h1>Laporan</h1><p>Rekap data anggota dan seluruh transaksi koperasi.</p></div><button class="btn primary" onclick="window.print()">Cetak Laporan</button></div>
<div class="stats"><div class="stat"><span>Anggota</span><strong><?=$anggota_count?></strong></div><div class="stat"><span>Simpanan</span><strong><?=rupiah($total_simpanan)?></strong></div><div class="stat"><span>Pinjaman</span><strong><?=rupiah($total_pinjaman)?></strong></div></div>
<div class="panel"><h2>Laporan Data Anggota</h2><?php $rows=$pdo->query("SELECT * FROM anggota ORDER BY nama")->fetchAll();?><div class="table-wrap"><table><thead><tr><th>No Anggota</th><th>Nama</th><th>JK</th><th>Telepon</th><th>Alamat</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['no_anggota'])?></td><td><?=e($r['nama'])?></td><td><?=e($r['jk'])?></td><td><?=e($r['telepon'])?></td><td><?=e($r['alamat'])?></td></tr><?php endforeach;?></tbody></table></div></div>
<div class="panel"><h2>Laporan Simpanan</h2><?php $rows=$pdo->query("SELECT s.*,a.nama FROM simpanan s JOIN anggota a ON a.id=s.anggota_id ORDER BY s.tanggal DESC")->fetchAll();?><div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Nama</th><th>Jenis</th><th>Jumlah</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['tanggal'])?></td><td><?=e($r['nama'])?></td><td><?=e($r['jenis'])?></td><td><?=rupiah($r['jumlah'])?></td></tr><?php endforeach;?></tbody></table></div></div>
<div class="panel"><h2>Laporan Pinjaman</h2><?php $rows=$pdo->query("SELECT p.*,a.nama,COALESCE(x.dibayar,0) dibayar FROM pinjaman p JOIN anggota a ON a.id=p.anggota_id LEFT JOIN (SELECT pinjaman_id,SUM(jumlah) dibayar FROM angsuran GROUP BY pinjaman_id) x ON x.pinjaman_id=p.id ORDER BY p.tanggal DESC")->fetchAll();?><div class="table-wrap"><table><thead><tr><th>Tanggal</th><th>Nama</th><th>Jumlah</th><th>Dibayar</th><th>Sisa</th><th>Status</th></tr></thead><tbody><?php foreach($rows as $r):$t=$r['jumlah']*(1+$r['bunga']/100);?><tr><td><?=e($r['tanggal'])?></td><td><?=e($r['nama'])?></td><td><?=rupiah($r['jumlah'])?></td><td><?=rupiah($r['dibayar'])?></td><td><?=rupiah(max(0,$t-$r['dibayar']))?></td><td><?=e($r['status'])?></td></tr><?php endforeach;?></tbody></table></div></div>
<?php endif;?>
</section></main></div><script src="assets/app.js"></script></body></html>
<?php
function render_table_recent($rows) {
 echo '<div class="table-wrap"><table><thead><tr><th>Jenis</th><th>Nama Anggota</th><th>Jumlah</th><th>Tanggal</th></tr></thead><tbody>';
 foreach($rows as $r) echo '<tr><td><span class="tag">'.e($r['tipe']).'</span></td><td>'.e($r['nama']).'</td><td>'.rupiah($r['jumlah']).'</td><td>'.e($r['tanggal']).'</td></tr>';
 echo '</tbody></table></div>';
}
